package com.example.tvinfo

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val black = Color.rgb(0, 0, 0)
    private val cardColor = Color.rgb(43, 43, 45)
    private val white = Color.rgb(244, 244, 246)
    private val gray = Color.rgb(170, 170, 174)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = black
        window.navigationBarColor = black
        val scroll = ScrollView(this).apply { setBackgroundColor(black) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(24), dp(28), dp(36))
            setBackgroundColor(black
        ) }
        scroll.addView(page)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val back = text("‹", 34, white, false).apply { gravity = Gravity.CENTER; setPadding(0,0,dp(20),0) }
        top.addView(back, LinearLayout.LayoutParams(dp(42), dp(46)))
        top.addView(text("Informação", 22, white, true))
        page.addView(top)

        val heading = text("58\" Crystal UHD", 38, white, true).apply {
            setPadding(dp(18), dp(38), 0, dp(46))
        }
        page.addView(heading)
        page.addView(sectionTitle("Informações do aparelho"))

        val deviceCard = card()
        addField(deviceCard, "Nome do modelo", "UN58U8500FGXZD")
        addField(deviceCard, "Número de série", "Y5843X5W601616X")
        addField(deviceCard, "Hora da Tela do Painel da TV", "257 horas")
        val warranty = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(26), dp(18), dp(28)) }
        warranty.addView(text("Data de validade da garantia", 16, white, true))
        deviceCard.addView(warranty)
        page.addView(deviceCard)

        page.addView(sectionTitle("Informações do aplicativo", top = dp(28)))
        val appCard = card()
        val appInfo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(26), dp(18), dp(28)) }
        appInfo.addView(text("Versão do aplicativo", 16, white, true))
        appInfo.addView(text("4.IR02.1113", 16, gray, false).apply { setPadding(0, dp(8), 0, 0) })
        appCard.addView(appInfo)
        page.addView(appCard)

        page.addView(sectionTitle("Informações legais", top = dp(28)))
        val legalCard = card()
        legalCard.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(30), dp(18), dp(30))
            addView(text("Licenças de código aberto", 16, white, true))
        })
        page.addView(legalCard)
        setContentView(scroll)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(cardColor, 28)
    }

    private fun addField(card: LinearLayout, label: String, value: String) {
        val field = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(26), dp(18), dp(26)) }
        field.addView(text(label, 16, white, true))
        field.addView(text(value, 16, gray, false).apply { setPadding(0, dp(8), 0, 0) })
        card.addView(field)
        val line = View(this).apply { setBackgroundColor(Color.rgb(105,105,108)) }
        card.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)))
    }

    private fun sectionTitle(s: String, top: Int = dp(0)): TextView = text(s, 19, white, false).apply {
        setPadding(dp(18), top + dp(18), 0, dp(22))
    }

    private fun text(s: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = s
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
